<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Sak Tech Shop</title>
    <link rel="stylesheet" href="home.css" />
  </head>
  <body>
    <div class="whole">
      <nav>
        <header>
          <h2>Welcome to my shop</h2>
          <img class="header-logo" src="/6 + 7 project/img/home.png" alt="" />
          <ul>
            <li><a href="#top" class="navgation">Home</a></li>
            <li><a href="#about" class="navgation">About</a></li>
            <li><a href="#shop" class="navgation">Product</a></li>
            <li><a href="#contact-time" class="navgation">Contact</a></li>
          </ul>
        </header>
      </nav>
      <!-- Scroll anchor fixed -->
      <div id="top"></div>
      <h1 class="home-welcome">Sak Tech Shop</h1>
      <!-- home part -->
      <div class="welcome">
        <img
          class="home-logo"
          src="https://cdn.autonomous.ai/static/upload/images/common/upload/20200930/6f2cce37d2c.jpg"
          alt=""
        />
        <p>
          ! Welcome to my Tech store you will find the best product ever in
          here........
        </p>
      </div>
      <!-- about part -->
      <div id="about"></div>
      <h1 class="about-welcome">This is about us !!!</h1>
      <div class="about">
        <div class="text">
          <p class="text">
            We are a store that sells good quality technology. You can find
            laptops, computer parts, gaming gear, and smart gadgets here. Our
            goal is to help people find the right tech for their needs — for
            school, work, games, or fun. We choose our products carefully, so
            you can trust what you buy. Sak Tech Shop was started by someone who
            loves technology and wants to make it easy for everyone to get.
            Thank you for visiting our shop. We hope you enjoy your time here
            and find something great!
          </p>
        </div>
        <div class="about-pic">
          <img
            class="img-about"
            src="https://www.techspot.com/articles-info/2653/images/2023-03-29-image-11.jpg"
            alt=""
          />
        </div>
      </div>
      <!-- product part -->
      <div id="shop"></div>
      <h1 class="product-part">My Best product seller in my store</h1>
      <div class="product">
        <div class="box">
          <p class="product-name">Destop accessory</p>
          <a href="destkop.php">
            <img
              src="https://geekawhat.com/wp-content/uploads/2024/12/FI_APNX-V1-4070-Ti-SUPER.jpg"
              alt=""
            />
          </a>
        </div>
        <div class="box">
          <p class="product-name">laptops</p>
          <a href="laptop.php">
            <img
              src="https://cdn.gamerbraves.com/2023/08/Featured-Image-Laptop-MSI-Raider-GE78-HX.jpg"
              alt=""
            />
          </a>
        </div>
        <div class="box">
          <p class="product-name">Accessory pc</p>
          <a href="accessory.php">
            <img
              src="https://cdn.shopifycdn.net/s/files/1/0823/5050/6282/files/1_33571812-6d4b-4211-877e-1d808b0e3dad.jpg?v=1716349339"
              alt=""
            />
          </a>
        </div>
      </div>
      <div id="contact-time"></div>
      <h2 class="contact-header">Contact Us Now</h2>
      <div class="contact">
        <div class="information">
          <form>
            <label for="Email" name="Email">Email</label><br /><br />
            <input
              type="email"
              placeholder="Please fill your email..."
              required
            /><br />
            <textarea
              name="comment"
              placeholder="Write your wonder or anything here"
              required
            ></textarea
            ><br /><br />
            <button type="submit">Submit</button>
          </form>
        </div>
      </div>
    </div>
    <footer>
      <h1 class="infor">
        For more information You can contact us or support us by :
      </h1>
      <a href="https://www.facebook.com/sak.khath.52/"
        ><img
          class="contact-logo"
          src="https://img.freepik.com/premium-psd/facebook-social-media-icon-3d_466778-4384.jpg?semt=ais_items_boosted&w=740 "
          alt=""
      /></a>
      <a
        href="https://www.tiktok.com/@sakkkkoko?is_from_webapp=1&sender_device=pc"
        ><img
          class="contact-logo"
          src="https://static.vecteezy.com/system/resources/previews/023/986/492/non_2x/tiktok-logo-tiktok-logo-transparent-tiktok-icon-transparent-free-free-png.png"
          alt=""
      /></a>
      <a href="https://www.youtube.com/"
        ><img
          class="contact-logo"
          src="https://static.vecteezy.com/system/resources/thumbnails/023/986/480/small_2x/youtube-logo-youtube-logo-transparent-youtube-icon-transparent-free-free-png.png"
          alt=""
      /></a>
      <a href="https://t.me/contact/1750868641:ftZF9dB3de9s37PL"
        ><img
          class="contact-logo"
          src="https://thumbs.dreamstime.com/b/samara-russian-federation-august-telegram-logo-icon-telegrams-one-most-popular-instant-messengers-editorial-animation-123001349.jpg"
          alt=""
      /></a>
    </footer>
  </body>
</html>
