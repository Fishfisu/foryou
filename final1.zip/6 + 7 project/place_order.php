<?php
// place_order.php
// This script receives form data and saves orders into a CSV file or database

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $product_name = trim($_POST['product_name'] ?? '');
    $product_price = floatval($_POST['product_price'] ?? 0);
    $quantity = intval($_POST['quantity'] ?? 1);
    $fullname = trim($_POST['fullname'] ?? '');
    $phone = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $payment_type = $_POST['payment_type'] ?? '';

    if (
        !$product_name || $product_price <= 0 || $quantity <= 0 ||
        !$fullname || !$phone || !$address || !in_array($payment_type, ['Cash', 'Online'])
    ) {
        echo "Invalid input. Please go back and fill the form correctly.";
        exit;
    }

    // Calculate total price
    $total = $product_price * $quantity;
    $order_date = date('Y-m-d H:i:s');
    $payment_status = 'Not Paid';

    // Save order data - here we save in CSV file (orders.csv)
    $order_data = [
        $order_date,
        $fullname,
        $phone,
        $address,
        $product_name,
        $quantity,
        number_format($total, 2),
        $payment_type,
        $payment_status
    ];

    $file = fopen('orders.csv', 'a');
    if ($file) {
        fputcsv($file, $order_data);
        fclose($file);
        echo "<p>Thank you, <strong>" . htmlspecialchars($fullname) . "</strong>. Your order for <strong>" . htmlspecialchars($product_name) . "</strong> has been placed.</p>";
        echo '<p><a href="laptop.php">Back to shop</a></p>';
    } else {
        echo "Failed to save your order. Please try again later.";
    }
} else {
    // Redirect back if accessed directly
    header("Location: laptop.php");
    exit;
}
