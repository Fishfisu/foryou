<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Laptop Shop</title>
  <style>
    body {
      font-family: sans-serif;
      background-color: #f2f2f2;
      padding: 20px;
    }

    h1 {
      text-align: center;
      margin-bottom: 30px;
    }

    .row {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
    }

    .tuf {
      position: relative;
      width: 300px;
      padding: 15px;
      background-color: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 12px;
      text-align: center;
    }

    .tuf img {
      width: 100%;
      height: 220px;
      object-fit: cover;
      border-radius: 8px;
      transition: transform 0.3s;
    }

    .tuf img:hover {
      transform: scale(1.05);
    }

    .tuf button {
      position: absolute;
      top: 10px;
      left: 10px;
      padding: 5px 10px;
      background-color: crimson;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 14px;
      cursor: default;
    }

    .tuf .original-price {
      text-decoration: line-through;
      color: gray;
      margin: 10px 0 0;
    }

    .tuf span {
      font-size: 18px;
      color: green;
      display: block;
      margin-bottom: 10px;
    }

    .tuf .product-name {
      font-weight: bold;
      margin-top: 10px;
      font-size: 16px;
    }
  </style>
</head>
<body>

  <h1>Laptop Shop</h1>

  <div class="row">

    <!-- Asus (3) -->
    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">790 $</p>
      <span>759 $</span>
      <a href="buy.php?product=Asus TUF F15">
        <img src="https://dlcdnwebimgs.asus.com/gain/5ae091bf-7471-4108-b11d-e6dc81279f5f/" alt="Asus TUF F15"/>
      </a>
      <p class="product-name">Asus TUF F15</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">1100 $</p>
      <span>1000 $</span>
      <a href="buy.php?product=Asus TUF F17">
        <img src="https://static.ollo.it/img/catalog/360x360/asus-tuf-gaming-f17-fx707vv-hx131w-core-i7-13620h-17-3-fullhd-144hz-rtx-4060_1393476_912401.jpg" alt="Asus TUF F17"/>
      </a>
      <p class="product-name">Asus TUF F17</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">1250 $</p>
      <span>1199 $</span>
      <a href="buy.php?product=Asus TUF Dash F15">
        <img src="https://dlcdnwebimgs.asus.com/gain/B0E929E7-92FA-4A5D-A5D6-78A39D9BE3CA" alt="Asus TUF Dash F15"/>
      </a>
      <p class="product-name">Asus TUF Dash F15</p>
    </div>

    <!-- ROG (3) -->
    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">1400 $</p>
      <span>1350 $</span>
      <a href="buy.php?product=ROG Strix G16">
        <img src="https://dlcdnwebimgs.asus.com/gain/CFE9CB59-216D-4AC9-AEAE-10054506055C/w1000/h732" alt="ROG Strix G16"/>
      </a>
      <p class="product-name">ROG Strix G16</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">1399 $</p>
      <span>1320 $</span>
      <a href="buy.php?product=ROG Strix G17">
        <img src="https://bcscomputer.net/userfiles/product/1024x768/27d01df052972ded63d446a794d568a8.jpg" alt="ROG strix g17"/>
      </a>
      <p class="product-name">ROG Strix G17</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">1600 $</p>
      <span>1499 $</span>
      <a href="buy.php?product=ROG Strix G18">
        <img src="https://dlcdnwebimgs.asus.com/gain/2BF5F03B-E120-4523-BBFF-AA8939E19B64" alt="ROG strix g18"/>
      </a>
      <p class="product-name">ROG Strix G18</p>
    </div>

    <!-- MSI (3) -->
    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">700 $</p>
      <span>650 $</span>
      <a href="buy.php?product=MSI Thin 16">
        <img src="https://sg.store.asus.com/media/catalog/product/cache/d598e30e6b04297db3b6c681f4709627/a/s/asus_tuf_gaming_f16_03_l.png" alt="MSI Thin 16"/>
      </a>
      <p class="product-name">MSI Thin 16</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">850 $</p>
      <span>799 $</span>
      <a href="buy.php?product=MSI Katana 15">
        <img src="https://www.jbhifi.com.au/cdn/shop/files/749816-Product-0-I-638521198841174574_67ae10db-b5cb-40db-aa7a-05c830dac966.jpg?v=1718771846" alt="MSI katana 15"/>
      </a>
      <p class="product-name">MSI Katana 15</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="original-price">900 $</p>
      <span>849 $</span>
      <a href="buy.php?product=MSI Raider">
        <img src="https://my-store.msi.com/cdn/shop/files/GE78HX14VI_1_256b0600-fc55-4f80-9ea6-2edd8dd332d2.png?v=1722419494" alt="MSI Raider"/>
      </a>
      <p class="product-name">MSI Raider</p>
    </div>

  </div>

</body>
</html>


