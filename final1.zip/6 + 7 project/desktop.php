<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Desktop Page</title>
  <style>
    body {
      font-family: sans-serif;
      background-color: #f2f2f2;
      padding: 20px;
    }

    h1 {
      text-align: center;
      margin-bottom: 30px;
    }

    .back-button {
      display: block;
      margin: 10px 0 30px;
      padding: 10px 20px;
      font-size: 16px;
      background-color: #333;
      color: white;
      border: none;
      border-radius: 5px;
      cursor: pointer;
    }

    .row {
      display: flex;
      flex-wrap: wrap;
      justify-content: center;
      gap: 30px;
    }

    .tuf {
      position: relative;
      width: 300px;
      padding: 15px;
      background-color: white;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
      border-radius: 12px;
      text-align: center;
      transition: transform 0.2s ease;
    }

    .tuf:hover {
      transform: scale(1.03);
    }

    .tuf img {
      width: 100%;
      height: 220px;
      object-fit: cover;
      border-radius: 8px;
      transition: transform 0.3s;
    }

    .tuf img:hover {
      transform: scale(1.05);
    }

    .tuf button {
      position: absolute;
      top: 10px;
      left: 10px;
      padding: 5px 10px;
      background-color: crimson;
      color: white;
      border: none;
      border-radius: 5px;
      font-size: 14px;
      cursor: default;
    }

    .tuf .orginal-price {
      text-decoration: line-through;
      color: gray;
      margin: 10px 0 0;
    }

    .tuf span {
      font-size: 18px;
      color: green;
      display: block;
      margin-bottom: 10px;
    }

    .tuf .product-name {
      font-weight: bold;
      margin-top: 10px;
      font-size: 16px;
    }

    a {
      text-decoration: none;
      color: inherit;
    }
  </style>
</head>
<body>

  <button onclick="history.back()" class="back-button">← Back</button>
  <h1>Top Selling Desktop Parts</h1>

  <div class="row">
    <!-- CPU -->
    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">570 $</p>
      <span>520 $</span>
      <a href="buy.php?id=1">
        <img src="https://m.media-amazon.com/images/I/61ZCD4bL89L.jpg" alt="Intel Core i9" />
      </a>
      <p class="product-name">Intel® Core™ i9</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">450 $</p>
      <span>400 $</span>
      <a href="buy.php?id=2">
        <img src="https://www.goldonecomputer.com/image/cache/catalog/Products/CPU/Intel%20Core%20i7%E2%80%8B%E2%80%8B%E2%80%8B%2014700KF-500x500.jpg" alt="Intel Core i7" />
      </a>
      <p class="product-name">Intel® Core™ i7</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">490 $</p>
      <span>450 $</span>
      <a href="buy.php?id=3">
        <img src="https://store974.com/cdn/shop/products/NewProject-2022-04-06T120620.137-626088.jpg?v=1649282093" alt="AMD Ryzen 9" />
      </a>
      <p class="product-name">AMD Ryzen 9</p>
    </div>

    <!-- GPU -->
    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">3000 $</p>
      <span>2900 $</span>
      <a href="buy.php?id=4">
        <img src="https://hwbusters.com/wp-content/uploads/2022/11/Asus-Rog-Strix-RTX-40903.jpeg" alt="Nvidia RTX 4090" />
      </a>
      <p class="product-name">Nvidia RTX 4090</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">2800 $</p>
      <span>2700 $</span>
      <a href="buy.php?id=5">
        <img src="https://asset.msi.com/resize/image/global/product/product_1668062791d5e83a0a428d9b516392bbf97b12a90e.png62405b38c58fe0f07fcef2367d8a9ba1/1024.png" alt="Nvidia RTX 4080" />
      </a>
      <p class="product-name">Nvidia RTX 4080</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">4000 $</p>
      <span>3900 $</span>
      <a href="buy.php?id=6">
        <img src="https://www.zotac.com/download/files/styles/w1024/public/product_gallery/graphics_cards/zt-b50900d-10p-image01.jpg?itok=G9okpvmL" alt="Nvidia RTX 5090" />
      </a>
      <p class="product-name">Nvidia RTX 5090</p>
    </div>

    <!-- RAM -->
    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">40 $</p>
      <span>35 $</span>
      <a href="buy.php?id=7">
        <img src="https://image-cdn.jambuntech.dev/MIr24Cf-IJY2kczTZZkGjfr8qIfPGPy3FD7Qgo36/1920x/filters:format(webp)/tk-files/vengeance_pro_ddr_2_pcs_4654e75b185e7252896b8d27cfc36f75.png" alt="RAM 16GB" />
      </a>
      <p class="product-name">RAM 16GB</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">70 $</p>
      <span>65 $</span>
      <a href="buy.php?id=8">
        <img src="https://m.media-amazon.com/images/I/713M7H5BexL.jpg" alt="RAM 32GB" />
      </a>
      <p class="product-name">RAM 32GB</p>
    </div>

    <div class="tuf">
      <button>Discount</button>
      <p class="orginal-price">100 $</p>
      <span>90 $</span>
      <a href="buy.php?id=9">
        <img src="https://m.media-amazon.com/images/I/71iVynpt3rL.jpg" alt="RAM 64GB" />
      </a>
      <p class="product-name">RAM 64GB</p>
    </div>
  </div>

</body>
</html>