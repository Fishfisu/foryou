<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Laptop page</title>
    <style>
      html,
      body {
        font-family: sans-serif;
        display: flex;
        flex-wrap: wrap;
      }
      /* Navigation Styles */
      nav {
        background-color: black;
        position: relative;
        position: fixed;
        width: 100%;
        top: 0;
        left: 0;
      }

      .nav-container {
        display: flex;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
      }

      .home {
        height: 60px;
      }

      ul {
        display: flex;
        gap: 50px;
        list-style: none;
        margin: 0;
        padding: 0;
        height: 50px;
      }

      li {
        display: flex;
        align-items: center;
      }

      .navigation {
        height: 60px;
      }
      .item1,
      .item2,
      .item3 {
        flex-wrap: wrap;
        position: relative;
        width: 100%;
        display: flex;
        gap: 10%;
      }
      .tuf-item,
      .rog-item,
      .msi-item {
        margin-top: 10%;
        font-size: 4rem;
      }
      .tuf,
      .rog,
      .msi {
        width: 25%;
        height: 500px;
      }
      .tuf img {
        margin-left: 25%;
        margin-top: 10%;
        width: 400px;
        height: 400px;
        object-fit: covers;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
          rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
      }
      button {
        color: white;
        height: 5%;
        font-weight: bolder;
        background-color: red;
        border: none;
        border-radius: 4px;
        position: absolute;
        margin-top: 3.5%;
        margin-left: 7%;
      }
      .orginal-price {
        position: absolute;
        text-decoration: line-through;
        margin-top: 5%;
        margin-left: 8%;
      }
      span {
        position: absolute;
        display: flex;
        align-items: center;
        color: white;
        padding: 1%;
        margin-top: 3%;
        font-weight: bolder;
        margin-left: 23%;
        background-color: red;
        border: 1px solid yellow;
        height: 2%;
        border-radius: 10px;
      }
      .product-name {
        position: absolute;
        margin-left: 10%;
        font-size: 2rem;
      }
      /* gpu */
      .rog img {
        margin-left: 25%;
        margin-top: 10%;
        width: 400px;
        height: 400px;
        object-fit: covers;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
          rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
      }
      /* headphone */
      .msi img {
        margin-left: 25%;
        margin-top: 10%;
        width: 400px;
        height: 400px;
        object-fit: covers;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
          rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
      }
      /* responsive part */
      @media screen and (max-width: 660px) {
        nav {
          background-color: black;
          position: relative;
          position: fixed;
          width: 100%;
          top: 0;
          left: 0;
        }

        .nav-container {
          display: flex;
          align-items: center;
          justify-content: space-between;
          padding: 5px;
        }

        .home {
          height: 40px;
        }

        ul {
          display: flex;
          gap: 20px;
          list-style: none;
          margin: 0;
          padding: 0;
          height: 50px;
        }

        li {
          display: flex;
          align-items: center;
        }

        .navigation {
          height: 40px;
        }
        .item1,
        .item2,
        .item3 {
          flex-direction: column;
          justify-content: center;
          position: relative;
          width: 100%;
        }
        .tuf-item,
        .rog-item,
        .msi-item {
          text-align: center;
          margin-top: 20%;
          font-size: 2rem;
        }
        .tuf,
        .rog,
        .msi {
          width: 30%;
          height: 500px;
          margin-left: 5%;
        }
        button {
          color: white;
          height: 20px;
          font-weight: bolder;
          background-color: red;
          border: none;
          border-radius: 4px;
          position: absolute;
          margin-top: 3.5%;
          margin-left: 7%;
        }

        span {
          position: absolute;
          text-align: center;
          color: white;

          margin-top: 3%;
          font-weight: bolder;
          margin-left: 65%;
          background-color: red;
          border: 1px solid yellow;
          height: 2%;
          width: 40px;
          border-radius: 10px;
        }
        .orginal-price {
          position: absolute;
          text-decoration: line-through;
          margin-top: 10%;
          margin-left: 8%;
        }
        .tuf img {
          margin-top: 10%;
          width: 300px;
          height: 300px;
          object-fit: covers;
          box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
            rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
        }

        .rog img {
          margin-left: 25%;
          margin-top: 10%;
          width: 300px;
          height: 300px;
          object-fit: covers;
          box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
            rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
        }
        /* headphone */

        .msi img {
          margin-left: 25%;
          margin-top: 10%;
          width: 300px;
          height: 300px;
          object-fit: covers;
          box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
            rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
        }
      }
    </style>
  </head>
  <body>
    <!-- Navigation Bar -->
    <nav>
      <div class="nav-container">
        <a href="indext.html">
          <img
            class="home"
            src="https://i.pinimg.com/736x/21/e5/30/21e530158ad29f82b80434d291400e37.jpg"
            alt="Home"
          />
        </a>
        <ul>
          <li>
            <a href="destkop.html">
              <img
                class="navigation"
                src="/6 + 7 project/img/destop.png"
                alt="About"
              />
            </a>
          </li>
          <li>
            <a href="laptop.html">
              <img
                class="navigation"
                src="/6 + 7 project/img/laptop.png"
                alt="Contact"
              />
            </a>
          </li>
          <li>
            <a href="accessory.html">
              <img
                class="navigation"
                src="/6 + 7 project/img/accessory.png"
                alt="Shop"
              />
            </a>
          </li>
        </ul>
      </div>
    </nav>
    <!-- product part -->
    <!-- cpu part -->
    <p class="tuf-item">My Top seller Ausu TUF</p>
    <div class="item1">
      <div class="tuf">
        <button>Discount</button>
        <p class="orginal-price">790 $</p>
        <span>759 $</span>
        <a href="buy.php?id=1"></a>
        <img
          src="https://dlcdnwebimgs.asus.com/gain/5ae091bf-7471-4108-b11d-e6dc81279f5f/"
          alt=""
        />
        <p class="product-name">Asus TUF F15</p>
      </div>
      <div class="tuf">
        <button>Discount</button>
        <p class="orginal-price">1100 $</p>
        <span>1000 $</span>
        <img
          src="https://static.ollo.it/img/catalog/360x360/asus-tuf-gaming-f17-fx707vv-hx131w-core-i7-13620h-17-3-fullhd-144hz-rtx-4060_1393476_912401.jpg"
          alt=""
        />
        <p class="product-name">Asus TUF F17</p>
      </div>
      <div class="tuf">
        <button>Discount</button>
        <p class="orginal-price">1300 $</p>
        <span>1200 $</span>
        <img
          src="https://sg.store.asus.com/media/catalog/product/cache/d598e30e6b04297db3b6c681f4709627/a/s/asus_tuf_gaming_f16_03_l.png"
          alt=""
        />
        <p class="product-name">Asus TUF f16</p>
      </div>
    </div>
    <!-- gpu part -->
    <p class="rog-item">My Top seller ROG</p>
    <div class="item2">
      <div class="rog">
        <button>Discount</button>
        <p class="orginal-price">1400$</p>
        <span>1350 $</span>
        <img
          src="https://dlcdnwebimgs.asus.com/gain/CFE9CB59-216D-4AC9-AEAE-10054506055C/w1000/h732"
          alt=""
        />
        <p class="product-name">ROG strix g16</p>
      </div>
      <div class="rog">
        <button>Discount</button>
        <p class="orginal-price">1800 $</p>
        <span>1700 $</span>
        <img
          src="https://bcscomputer.net/userfiles/product/1024x768/27d01df052972ded63d446a794d568a8.jpg"
          alt=""
        />
        <p class="product-name">ROG strix g17</p>
      </div>
      <div class="rog">
        <button>Discount</button>
        <p class="orginal-price">1900 $</p>
        <span>1800 $</span>
        <img
          src="https://dlcdnwebimgs.asus.com/gain/2BF5F03B-E120-4523-BBFF-AA8939E19B64"
          alt=""
        />
        <p class="product-name">ROG strix g18</p>
      </div>
    </div>
    <!-- ram part -->
    <p class="msi-item">My top seller MSI</p>
    s
    <div class="item3">
      <div class="msi">
        <button>Discount</button>
        <p class="orginal-price">700 $</p>
        <span>650 $</span>
        <img
          src="https://www.stephanis.com.cy/media/products/LAT_FB1780C072D55.jpg?dimensions=1000x1000"
        />
        <p class="product-name">MSI Thin 15</p>
      </div>
      <div class="msi">
        <button>Discount</button>
        <p class="orginal-price">1500 $</p>
        <span>1399 $</span>
        <img
          src="https://www.jbhifi.com.au/cdn/shop/files/749816-Product-0-I-638521198841174574_67ae10db-b5cb-40db-aa7a-05c830dac966.jpg?v=1718771846"
          alt=""
        />
        <p class="product-name">MSI katana 15</p>
      </div>
      <div class="msi">
        <button>Discount</button>
        <p class="orginal-price">4000 $</p>
        <span>3899 $</span>
        <img
          src="https://my-store.msi.com/cdn/shop/files/GE78HX14VI_1_256b0600-fc55-4f80-9ea6-2edd8dd332d2.png?v=1722419494"
          alt=""
        />
        <p class="product-name">MSI Raider</p>
      </div>
    </div>
  </body>
</html> 