<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Accessory Page</title>
    <style>
      html,
      body {
        font-family: sans-serif;
        display: flex;
        flex-wrap: wrap;
        margin: 0;
        padding: 0;
        justify-content: center;
        position: relative;
        min-height: 100vh;
      }

      /* Back Button */
      .back-button {
        position: fixed;
        top: 15px;
        left: 15px;
        background-color: #333;
        color: white;
        padding: 6px 12px;
        border: none;
        border-radius: 4px;
        cursor: pointer;
        font-weight: normal;
        font-size: 14px;
        z-index: 1000;
        text-decoration: none;
        display: inline-flex;
        align-items: center;
        transition: background-color 0.3s ease;
        box-shadow: 0 2px 5px rgba(0, 0, 0, 0.3);
      }
      .back-button:hover {
        background-color: #555;
      }

      /* Sections */
      .item1,
      .item2,
      .item3 {
        flex-wrap: wrap;
        position: relative;
        width: 100%;
        display: flex;
        gap: 10%;
        margin-top: 80px; /* leave space for back button */
        padding-bottom: 40px;
        justify-content: center;
      }

      p.mouse-item,
      p.keybord-item,
      p.headphone-item {
        margin-top: 80px;
        width: 100%;
        font-size: 3rem;
        font-weight: bold;
        text-align: center;
      }

      /* Product Cards as squares */
      .mouse,
      .keybord,
      .headphone {
        width: 300px;
        height: 300px; /* square */
        position: relative;
        box-shadow: rgba(0, 0, 0, 0.16) 0px 10px 36px 0px,
          rgba(0, 0, 0, 0.06) 0px 0px 0px 1px;
        border-radius: 10px;
        background: white;
        overflow: hidden;
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: space-between;
        padding: 10px;
        box-sizing: border-box;
      }

      /* Images fill most of card but keep aspect ratio */
      .mouse img,
      .keybord img,
      .headphone img {
        width: 90%;
        height: auto;
        max-height: 180px;
        object-fit: contain;
        cursor: pointer;
        border-radius: 10px;
        transition: transform 0.3s ease;
      }
      .mouse img:hover,
      .keybord img:hover,
      .headphone img:hover {
        transform: scale(1.05);
      }

      button {
        color: white;
        height: 25px;
        font-weight: bolder;
        background-color: red;
        border: none;
        border-radius: 4px;
        padding: 0 10px;
        cursor: default;
        align-self: flex-start;
      }

      .orginal-price {
        text-decoration: line-through;
        color: #999;
        font-weight: bold;
        font-size: 0.9rem;
      }

      span {
        color: white;
        background-color: red;
        border: 1px solid yellow;
        font-weight: bolder;
        font-size: 0.9rem;
        padding: 2px 8px;
        border-radius: 10px;
        margin-left: 10px;
      }

      .price-container {
        display: flex;
        align-items: center;
        gap: 10px;
      }

      .product-name {
        font-size: 1.3rem;
        font-weight: 600;
        color: #333;
        text-align: center;
        margin-top: 5px;
      }

      /* Responsive */
      @media screen and (max-width: 660px) {
        .item1,
        .item2,
        .item3 {
          flex-direction: column;
          align-items: center;
          gap: 30px;
          margin-top: 100px;
        }

        .mouse,
        .keybord,
        .headphone {
          width: 80%;
          height: auto;
          padding: 20px;
        }

        .mouse img,
        .keybord img,
        .headphone img {
          width: 100%;
          max-height: 250px;
          margin-bottom: 10px;
        }

        button,
        .orginal-price,
        span,
        .product-name {
          align-self: center;
          margin: 0;
        }

        .price-container {
          justify-content: center;
        }
      }
    </style>
  </head>
  <body>
    <!-- Back Button -->
    <a href="javascript:history.back()" class="back-button">← Back</a>

    <!-- Mouse part -->
    <p class="mouse-item">My Top seller Mouse Attack Model</p>
    <div class="item1">
      <div class="mouse">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">28 $</p>
          <span>22 $</span>
        </div>
        <a href="buy.php?id=1">
          <img
            src="https://m.media-amazon.com/images/I/61Pn2Gw22LL.jpg"
            alt="Attack Shark X11"
          />
        </a>
        <p class="product-name">Attack Shark X11</p>
      </div>
      <div class="mouse">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">40 $</p>
          <span>35 $</span>
        </div>
        <a href="buy.php?id=2">
          <img
            src="https://m.media-amazon.com/images/I/513wMuwZsQL.jpg"
            alt="Attack Shark X3"
          />
        </a>
        <p class="product-name">Attack Shark X3</p>
      </div>
      <div class="mouse">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">60 $</p>
          <span>52 $</span>
        </div>
        <a href="buy.php?id=3">
          <img
            src="https://attackshark.com/cdn/shop/files/6_64e3fbed-0685-4cff-8650-13bf45b17a80.jpg?v=1737168023&width=1600"
            alt="Attack Shark R3"
          />
        </a>
        <p class="product-name">Attack Shark R3</p>
      </div>
    </div>

    <!-- Keyboard part -->
    <p class="keybord-item">My Top seller Keyboard</p>
    <div class="item2">
      <div class="keybord">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">55 $</p>
          <span>45 $</span>
        </div>
        <a href="buy.php?id=4">
          <img
            src="https://m.media-amazon.com/images/I/61T79euEq2L.jpg"
            alt="Aula F75"
          />
        </a>
        <p class="product-name">Aula F75</p>
      </div>
      <div class="keybord">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">70 $</p>
          <span>65 $</span>
        </div>
        <a href="buy.php?id=5">
          <img
            src="https://sm.ign.com/t/ign_me/screenshot/default/thm_vawx.1200.jpg"
            alt="Leobog Hi75"
          />
        </a>
        <p class="product-name">Leobog Hi75</p>
      </div>
      <div class="keybord">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">48 $</p>
          <span>40 $</span>
        </div>
        <a href="buy.php?id=6">
          <img
            src="https://vibegaming.com.bd/wp-content/uploads/2025/01/White-66.png"
            alt="Mad 60 HE"
          />
        </a>
        <p class="product-name">Mad 60 HE</p>
      </div>
    </div>

    <!-- Headphone part -->
    <p class="headphone-item">My Top seller of Headphone</p>
    <div class="item3">
      <div class="headphone">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">120 $</p>
          <span>100 $</span>
        </div>
        <a href="buy.php?id=7">
          <img
            src="https://m.media-amazon.com/images/I/51vUMenoNkL._UF1000,1000_QL80_.jpg"
            alt="Razer shark v2"
          />
        </a>
        <p class="product-name">Razer shark v2</p>
      </div>
      <div class="headphone">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">50 $</p>
          <span>45 $</span>
        </div>
        <a href="buy.php?id=8">
          <img
            src="https://www.marvo-tech.com/cdn/shop/files/1_a0a19229-ff3c-41ec-8069-650d4f4b9907_800x.jpg?v=1700534715"
            alt="Monka edition"
          />
        </a>
        <p class="product-name">Monka edition</p>
      </div>
      <div class="headphone">
        <button>Discount</button>
        <div class="price-container">
          <p class="orginal-price">100 $</p>
          <span>90 $</span>
        </div>
        <a href="buy.php?id=9">
          <img
            src="https://www.ione.com.kh/wp-content/uploads/2021/05/Apple-AirPods-Max-ione-cambodia-2.jpg"
            alt="Apple Airpods"
          />
        </a>
        <p class="product-name">Apple Airpods</p>
      </div>
    </div>
  </body>
</html>




