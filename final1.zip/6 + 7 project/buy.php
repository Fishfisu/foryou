<?php
// buy.php
// This page shows product info based on id passed in URL, and shows form for order

// Simple products data array (id => details)
$products = [
    1 => ['name' => 'Attack Shark X11', 'price' => 22],
    2 => ['name' => 'Attack Shark X3', 'price' => 35],
    3 => ['name' => 'Attack Shark R3', 'price' => 52],
    4 => ['name' => 'Aula F75', 'price' => 45],
    5 => ['name' => 'Leobog Hi75', 'price' => 65],
    6 => ['name' => 'Mad 60 HE', 'price' => 40],
    7 => ['name' => 'Razer shark v2', 'price' => 100],
    8 => ['name' => 'Monka edition', 'price' => 45],
    9 => ['name' => 'Apple Airpods', 'price' => 90],
];

// Get product ID from URL
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (!isset($products[$id])) {
    echo "Invalid product ID.";
    exit;
}

$product = $products[$id];
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>Buy <?php echo htmlspecialchars($product['name']); ?></title>
  <style>
    body { font-family: Arial, sans-serif; padding: 20px; background: #f9f9f9; }
    .container { max-width: 500px; margin: auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 0 10px #ccc; }
    h2 { text-align: center; }
    label { display: block; margin: 10px 0 5px; }
    input[type=text], input[type=tel], input[type=number], select { width: 100%; padding: 8px; border-radius: 4px; border: 1px solid #ccc; }
    button { margin-top: 15px; background: #28a745; color: white; border: none; padding: 10px; width: 100%; border-radius: 4px; font-size: 16px; cursor: pointer; }
    button:hover { background: #218838; }
  </style>
</head>
<body>
  <div class="container">
    <h2>Buy "<?php echo htmlspecialchars($product['name']); ?>"</h2>
    <p>Price: $<?php echo number_format($product['price'], 2); ?></p>

    <form action="place_order.php" method="post">
      <input type="hidden" name="product_name" value="<?php echo htmlspecialchars($product['name']); ?>">
      <input type="hidden" name="product_price" value="<?php echo $product['price']; ?>">

      <label for="quantity">Quantity:</label>
      <input type="number" id="quantity" name="quantity" min="1" value="1" required>

      <label for="fullname">Full Name:</label>
      <input type="text" id="fullname" name="fullname" required>

      <label for="phone">Phone Number:</label>
      <input type="tel" id="phone" name="phone" required pattern="[0-9+\-\s]{7,}">

      <label for="address">Address:</label>
      <input type="text" id="address" name="address" required>

      <label for="payment_type">Payment Type:</label>
      <select id="payment_type" name="payment_type" required>
        <option value="">-- Select Payment Method --</option>
        <option value="Cash">Cash on Delivery</option>
        <option value="Online">Online Payment</option>
      </select>

      <button type="submit">Place Order</button>
    </form>
  </div>
</body>
</html>
